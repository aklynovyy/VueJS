new Vue({
  el: '#app',
  data: {
    newTodoText: '',
    nextTodoId: 4,
    todos: [
      {id: 1, title: 'Купить молоко в магазине'},
      {id: 2, title: 'Почистить сковородку'},
      {id: 3, title: 'Погулять с собакой'}
    ]
  },
  methods: {
    addNewTodo: function () {
      this.todos.push({
        id: this.nextTodoId++,
        title: this.newTodoText
      })
      this.newTodoText = ''
    }
  },
  components: {
    'new-item': {
      template: '\
        <li>\
          {{ title }}\
          <button v-on:click="$emit(\'remove\')">Удалить</button>\
        </li>\
      ',
      props: ['title']
    }
  }
})
